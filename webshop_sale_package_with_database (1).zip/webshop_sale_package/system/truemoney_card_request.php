<?php
require_once __DIR__ . '/a_func.php';
header('Content-Type: application/json; charset=utf-8');
function card_json($ok, $message) { http_response_code($ok ? 200 : 400); exit(json_encode(['status'=>$ok?'success':'fail','message'=>$message], JSON_UNESCAPED_UNICODE)); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') card_json(false, 'Method not allowed');
if (!isset($_SESSION['id'])) card_json(false, 'กรุณาเข้าสู่ระบบก่อนส่งคำขอ');
$card = preg_replace('/\D+/', '', (string)($_POST['card_number'] ?? ''));
if (!preg_match('/^\d{14}$/', $card)) card_json(false, 'กรุณากรอกเลขบัตรทรูมันนี่ 14 หลัก');
// Create/migrate the request table safely for existing installations.
dd_q("CREATE TABLE IF NOT EXISTS truemoney_card_requests (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, username VARCHAR(255) NOT NULL, card_hash CHAR(64) NOT NULL, card_last4 CHAR(4) NOT NULL, card_encrypted TEXT NOT NULL, amount DECIMAL(10,2) NULL, status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending', admin_note VARCHAR(500) NOT NULL DEFAULT '', created_at DATETIME NOT NULL, reviewed_at DATETIME NULL, reviewed_by VARCHAR(255) NOT NULL DEFAULT '', INDEX(status), INDEX(card_hash), INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$existing = dd_q("SELECT id,status FROM truemoney_card_requests WHERE card_hash=? AND status IN ('pending','approved') LIMIT 1", [hash('sha256',$card)]);
if ($existing && $existing->fetch(PDO::FETCH_ASSOC)) card_json(false, 'บัตรใบนี้ถูกส่งคำขอหรืออนุมัติไปแล้ว');
$u = dd_q('SELECT id,username FROM users WHERE id=? LIMIT 1', [$_SESSION['id']]);
$user = $u ? $u->fetch(PDO::FETCH_ASSOC) : false;
if (!$user) card_json(false, 'ไม่พบข้อมูลผู้ใช้');
$key = hash('sha256', (string)($db_pass ?? 'omg-card-key'), true);
$iv = random_bytes(12); $tag='';
$cipher = openssl_encrypt($card, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
$encrypted = base64_encode($iv.$tag.$cipher);
$insert = dd_q('INSERT INTO truemoney_card_requests (user_id,username,card_hash,card_last4,card_encrypted,status,created_at) VALUES (?,?,?,?,?,\'pending\',NOW())', [(int)$user['id'],$user['username'],hash('sha256',$card),substr($card,-4),$encrypted]);
if (!$insert) card_json(false, 'ไม่สามารถบันทึกคำขอได้ กรุณาลองใหม่');
card_json(true, 'ส่งคำขอแล้ว กรุณารอแอดมินตรวจสอบภายใน 24 ชั่วโมง');
