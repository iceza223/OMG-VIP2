<?php
    error_reporting(0);
    ini_set('display_errors', '0');

    require_once '../a_func.php';

    function dd_return($status, $message) {
        $json = ['message' => $message];
        if ($status) {
            http_response_code(200);
            die(json_encode($json));
        }else{
            http_response_code(400);
            die(json_encode($json));
        }
    }

    //////////////////////////////////////////////////////////////////////////

    header('Content-Type: application/json; charset=utf-8;');

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_SESSION['id'])) {

        if ($_POST['id'] != "" AND $_POST['total'] != "" AND $_POST['point'] != "") {
            $target_id = (int) $_POST['id'];
            $new_rank = isset($_POST['rank']) ? (int) $_POST['rank'] : 0;
            if (!in_array($new_rank, [0, 1], true)) {
                dd_return(false, "ยศผู้ใช้งานไม่ถูกต้อง");
            }
            if ($target_id === (int) $_SESSION['id'] && $new_rank !== 1) {
                dd_return(false, "ไม่สามารถลดสิทธิ์บัญชีของตัวเองได้");
            }
            $q_1 = dd_q('SELECT * FROM users WHERE id = ? AND rank = 1 ', [$_SESSION['id']]);
            if ($q_1->rowCount() >= 1) {
                if($_POST['password'] != ""){
                    $insert = dd_q("UPDATE users SET password = ?  WHERE id = ?   
                    ", [
                        password_hash((string) $_POST['password'], PASSWORD_DEFAULT),
                        $_POST['id'],
                    ]);
                }
                $insert = dd_q("UPDATE users SET total = ? , point = ?, rank = ? WHERE id = ?
                ", [
                    $_POST['total'],
                    $_POST['point'],
                    $new_rank,
                    $target_id,
                ]);
                if($insert){
                    dd_return(true, "บันทึกสำเร็จ");
                }else{
                    dd_return(false, "SQL ผิดพลาด");
                }
            }else{
                dd_return(false, "เซสชั่นผิดพลาด โปรดล็อกอินใหม่");
                session_destroy();
            }
        }else{
            dd_return(false, "กรุณากรอกข้อมูลให้ครบ");
        }
        }else{
        dd_return(false, "เข้าสู่ระบบก่อน");
        }
    }else{
        dd_return(false, "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");
    }
?>
