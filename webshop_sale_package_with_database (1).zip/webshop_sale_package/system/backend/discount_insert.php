<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../../system/a_func.php';

function discount_json_error($message)
{
    echo json_encode(['status' => 'error', 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

function discount_date_value($value, $label)
{
    $value = trim((string) $value);
    if ($value === '') {
        return null;
    }
    $date = DateTime::createFromFormat('Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) {
        discount_json_error($label . 'ไม่ถูกต้อง');
    }
    return $value;
}

if (!isset($_SESSION['id']) || !isset($user['rank']) || $user['rank'] != '1') {
    discount_json_error('ไม่มีสิทธิ์เข้าถึง');
}

$code = strtoupper(preg_replace('/\s+/', '', trim((string) ($_POST['code'] ?? ''))));
$type = $_POST['type'] ?? 'percent';
$value = (float) ($_POST['value'] ?? 0);
$min = max(0, (float) ($_POST['min'] ?? 0));
$limit = (int) ($_POST['limit'] ?? 0);
$max_raw = trim((string) ($_POST['max'] ?? ''));
$max_discount = $max_raw === '' ? null : (float) $max_raw;
$start_date = discount_date_value($_POST['start'] ?? '', 'วันเริ่มใช้');
$end_date = discount_date_value($_POST['end'] ?? '', 'วันหมดอายุ');
$active = (int) ($_POST['active'] ?? 1) === 1 ? 1 : 0;

if (!preg_match('/^[A-Z0-9_-]{3,50}$/', $code)) {
    discount_json_error('รหัสโค้ดต้องมี 3–50 ตัวอักษร และใช้ได้เฉพาะ A-Z, 0-9, _ หรือ -');
}
if (!in_array($type, ['percent', 'fixed'], true)) {
    discount_json_error('ประเภทส่วนลดไม่ถูกต้อง');
}
if ($value <= 0) {
    discount_json_error('มูลค่าส่วนลดต้องมากกว่า 0');
}
if ($type === 'percent' && $value > 100) {
    discount_json_error('ส่วนลดเปอร์เซ็นต์ต้องไม่เกิน 100%');
}
if ($max_discount !== null && $max_discount < 0) {
    discount_json_error('เพดานส่วนลดต้องไม่ติดลบ');
}
if ($limit < 0) {
    discount_json_error('จำนวนครั้งที่ใช้ได้ต้องไม่ติดลบ');
}
if ($start_date && $end_date && $start_date > $end_date) {
    discount_json_error('วันหมดอายุต้องไม่ก่อนวันเริ่มใช้');
}

$check = dd_q('SELECT id FROM discount_codes WHERE code = ? LIMIT 1', [$code]);
if ($check && $check->rowCount() > 0) {
    discount_json_error('โค้ดนี้มีอยู่แล้ว');
}

$result = dd_q(
    'INSERT INTO discount_codes (code, discount_type, discount_value, min_purchase, max_discount, usage_limit, start_date, end_date, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [$code, $type, $value, $min, $max_discount, $limit > 0 ? $limit : null, $start_date, $end_date, $active]
);

if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'สร้างโค้ดส่วนลดสำเร็จ!'], JSON_UNESCAPED_UNICODE);
} else {
    discount_json_error('เกิดข้อผิดพลาด กรุณาลองใหม่');
}
