<?php
error_reporting(0);
ini_set('display_errors', '0');
require_once 'a_func.php';

function register_return($status, $message)
{
    http_response_code(200);
    echo json_encode([
        'status' => $status ? 'success' : 'fail',
        'message' => $message
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    register_return(false, 'Method ไม่ได้รับอนุญาต');
}
if (isset($_SESSION['id'])) {
    register_return(false, 'ออกจากระบบก่อน');
}

$user_reg = trim((string) ($_POST['user'] ?? ''));
$pwd_reg = (string) ($_POST['pass'] ?? '');
$pwd2_reg = (string) ($_POST['pass2'] ?? '');

if ($user_reg === '' || $pwd_reg === '' || $pwd2_reg === '') {
    register_return(false, 'กรุณากรอกข้อมูลให้ครบถ้วน');
}
if (strlen($user_reg) < 4 || strlen($user_reg) > 50) {
    register_return(false, 'ชื่อผู้ใช้ต้องมีความยาว 4–50 ตัวอักษร');
}
if (strlen($pwd_reg) < 6 || strlen($pwd_reg) > 255) {
    register_return(false, 'รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร');
}
if ($pwd_reg !== $pwd2_reg) {
    register_return(false, 'รหัสผ่านทั้งสองไม่ตรงกัน');
}
if (!preg_match('/^[a-zA-Z0-9_]+$/', $user_reg)) {
    register_return(false, 'ชื่อผู้ใช้ต้องประกอบด้วยตัวอักษร ตัวเลข หรือ _ เท่านั้น');
}

$secret = $conf['secretkey'] ?? '';
$captcha_response = (string) ($_POST['captcha'] ?? '');
if ($secret === '' || $captcha_response === '') {
    register_return(false, 'กรุณายืนยันตัวตน');
}

$ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query(['secret' => $secret, 'response' => $captcha_response]),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 3,
    CURLOPT_TIMEOUT => 8,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
]);
$verify = curl_exec($ch);
$curl_error = curl_error($ch);
curl_close($ch);
$captcha_success = $verify ? json_decode($verify, true) : null;
if (!$captcha_success || ($captcha_success['success'] ?? false) !== true) {
    register_return(false, $curl_error ? 'ไม่สามารถตรวจสอบ reCAPTCHA ได้ชั่วคราว' : 'กรุณายืนยันตัวตน');
}

$check = dd_q('SELECT id FROM users WHERE username = ? LIMIT 1', [$user_reg]);
if ($check && $check->rowCount() > 0) {
    register_return(false, 'ชื่อผู้ใช้นี้ถูกใช้งานแล้ว');
}

$hashed_password = password_hash($pwd_reg, PASSWORD_DEFAULT);
$result = dd_q('INSERT INTO users (username, password, date, point, total, rank) VALUES (?, ?, NOW(), 0, 0, 0)', [
    $user_reg,
    $hashed_password
]);

if ($result) {
    $q = dd_q('SELECT id FROM users WHERE username = ? LIMIT 1', [$user_reg]);
    $account = $q->fetch(PDO::FETCH_ASSOC);
    session_regenerate_id(true);
    $session_dir = __DIR__ . '/sessions';
    if (!is_dir($session_dir) && !mkdir($session_dir, 0700, true) && !is_dir($session_dir)) {
        register_return(false, 'ระบบเซสชันไม่พร้อมใช้งาน');
    }
    $session_token = bin2hex(random_bytes(32));
    $session_file = $session_dir . '/' . (int) $account['id'] . '.token';
    if (file_put_contents($session_file, $session_token, LOCK_EX) === false) {
        register_return(false, 'ระบบเซสชันไม่พร้อมใช้งาน');
    }
    $_SESSION['single_session_token'] = $session_token;
    $_SESSION['id'] = (int) $account['id'];
    register_return(true, 'สมัครสมาชิกสำเร็จ');
} else {
    register_return(false, 'เกิดข้อผิดพลาดในการสมัครสมาชิก');
}
