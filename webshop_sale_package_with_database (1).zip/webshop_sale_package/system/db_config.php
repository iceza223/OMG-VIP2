<?php
// Local sandbox configuration generated for this installation.
$host = '127.0.0.1';
$db_user = 'webshop_app';
$db_pass = '867a4156145e2ba245e6ac9b28491b8edf4d57cb';
$db = 'webshop_sale';
$db_port = 3306;
