<?php
require_once 'a_func.php';
require_once __DIR__ . '/discord_notify.php';


function record_discount_usage($discount_id, $user_id, $discount_amount)
{
    if (!$discount_id) {
        return;
    }

    $usage = dd_q(
        "INSERT IGNORE INTO discount_usage (code_id, user_id, discount_amount) VALUES (?, ?, ?)",
        [$discount_id, $user_id, $discount_amount]
    );
    if ($usage && $usage->rowCount() > 0) {
        dd_q("UPDATE discount_codes SET used_count = used_count + 1 WHERE id = ?", [$discount_id]);
    }
}

function dd_return($status, $prize, $message)
{
    if ($status) {
        if ($prize) {
            $salt = "prize";
        }

        $json = ["salt" => $salt, 'message' => $message];
        http_response_code(200);
        die(json_encode($json));
    } else {
        if ($prize == "error") {
            $salt = "error";
        } else {
            $salt  = "salt";
        }
        $json = ["salt" => $salt, 'message' => $message];
        http_response_code(400);
        die(json_encode($json));
    }
}

// //////////////////////////////////////////////////////////////////////////

header('Content-Type: application/json; charset=utf-8;');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_SESSION['id'])) {
        $p = dd_q("SELECT * FROM users WHERE id = ? ", [$_SESSION['id']]);
        $plr = $p->fetch(PDO::FETCH_ASSOC);
        if ($_POST['count'] != "" && intval($_POST['count']) == $_POST['count'] && $_POST['count'] > 0 && $_POST['id'] != "") {
            $count = intval($_POST['count']);
            if ($count !== 1) {
                dd_return(false, "error", "สินค้านี้ซื้อได้ครั้งละ 1 ชิ้นเท่านั้น");
            }
            $q_1 = dd_q('SELECT * FROM users WHERE id = ?', [$_SESSION['id']]);
            if ($count === 1) {

                if ($q_1->rowCount() >= 1) {
                    $row_1 = $q_1->fetch(PDO::FETCH_ASSOC);
                    $p = dd_q("SELECT * FROM box_product WHERE id = ? ", [$_POST['id']]);
                    if ($p->rowCount() >= 1) {
                        $pd = $p->fetch(PDO::FETCH_ASSOC);
                        $point = (int) $row_1['point'];
                        $price = (int) $pd['price'];
                        $all_price = $price * $count;
                        $discount_id = null;
                        $discount_amount = 0;
                        $discount_code = strtoupper(preg_replace('/\s+/', '', trim((string) ($_POST['discount_code'] ?? ''))));
                        if ($discount_code !== '') {
                            $discount_q = dd_q("SELECT * FROM discount_codes WHERE code = ? AND is_active = 1 LIMIT 1", [$discount_code]);
                            if (!$discount_q || $discount_q->rowCount() === 0) {
                                dd_return(false, "error", "ไม่พบโค้ดส่วนลดนี้");
                            }
                            $discount_row = $discount_q->fetch(PDO::FETCH_ASSOC);
                            if ($discount_row['usage_limit'] !== null && $discount_row['used_count'] >= $discount_row['usage_limit']) {
                                dd_return(false, "error", "โค้ดนี้ถูกใช้ครบจำนวนแล้ว");
                            }
                            if ($all_price < (float) $discount_row['min_purchase']) {
                                dd_return(false, "error", "ยอดซื้อขั้นต่ำ " . number_format($discount_row['min_purchase']) . " บาท");
                            }
                            if ($discount_row['start_date'] && date('Y-m-d') < $discount_row['start_date']) {
                                dd_return(false, "error", "โค้ดยังไม่เริ่มใช้งาน");
                            }
                            if ($discount_row['end_date'] && date('Y-m-d') > $discount_row['end_date']) {
                                dd_return(false, "error", "โค้ดหมดอายุแล้ว");
                            }
                            $used_q = dd_q("SELECT id FROM discount_usage WHERE code_id = ? AND user_id = ? LIMIT 1", [$discount_row['id'], $_SESSION['id']]);
                            if ($used_q && $used_q->rowCount() > 0) {
                                dd_return(false, "error", "คุณเคยใช้โค้ดนี้แล้ว");
                            }
                            $discount_id = (int) $discount_row['id'];
                            if ($discount_row['discount_type'] === 'percent') {
                                $discount_amount = ($all_price * (float) $discount_row['discount_value']) / 100;
                                if ($discount_row['max_discount'] !== null) {
                                    $discount_amount = min($discount_amount, (float) $discount_row['max_discount']);
                                }
                            } else {
                                $discount_amount = (float) $discount_row['discount_value'];
                            }
                            $discount_amount = min(max(0, $discount_amount), (float) $all_price);
                            $all_price = max(0, $all_price - $discount_amount);
                        }
                        if ($point >= $all_price) {
                            $find_stock = dd_q("SELECT * FROM box_stock WHERE p_id = ? ", [$pd['id']]);
                            $notifyPurchase = static function () use ($row_1, $pd, $count, $all_price): void {
                                send_discord_transaction_notification(
                                    'purchase',
                                    'มีการสั่งซื้อสินค้าใหม่',
                                    'ระบบได้รับคำสั่งซื้อสินค้าเรียบร้อยแล้ว',
                                    [
                                        ['name' => 'ชื่อผู้ใช้', 'value' => (string) ($row_1['username'] ?? '-')],
                                        ['name' => 'ชื่อสินค้า', 'value' => (string) ($pd['name'] ?? '-')],
                                        ['name' => 'จำนวน', 'value' => (string) $count . ' ชิ้น'],
                                        ['name' => 'ราคา', 'value' => number_format((float) $all_price, 2) . ' บาท'],
                                    ],
                                    3368703
                                );
                            };

                            if ($pd['type'] == "1" and $find_stock->rowCount() >= $count) {
                                for ($i = 1; $i <= $count; $i++) {
                                    $find_stock = dd_q("SELECT * FROM box_stock WHERE p_id = ? LIMIT 1", [$pd['id']]);
                                    if ($find_stock->rowCount() == 1) {
                                        $stock = $find_stock->fetch(PDO::FETCH_ASSOC);
                                        $del = dd_q("DELETE FROM box_stock WHERE id = ? ", [$stock['id']]);
                                        $upt = dd_q("UPDATE users SET point = point - ? WHERE id = ? ", [$all_price / $count, $_SESSION['id']]);
                                        $insert = dd_q("INSERT INTO boxlog (date , username , category , price , prize_name , uid)
                                        VALUES ( NOW() , ? , ? , ? , ? , ?  ) 
                                        ", [
                                            $row_1["username"],
                                            $pd["name"],
                                            $pd["price"],
                                            $stock["username"],
                                            $_SESSION['id']
                                        ]);
                                    } else {
                                        dd_return(false, "ได้รับสินค้าแค่บางส่วน");
                                        break;
                                    }
                                }
                                if ($insert  and $del) {
                                    $notifyPurchase();
                                    record_discount_usage($discount_id, $_SESSION['id'], $discount_amount);
                                    dd_return(true, true, "ซื้อสินค้าสำเร็จ !");
                                } else {
                                    dd_return(false, "error", "[ERROR API BUY] โปรดติดต่อเจ้าของเว็บ!");
                                }
                            } elseif ($pd['type'] == "0" && $find_stock->rowCount() > 0) {
                                if ($find_stock->rowCount() > 0) {
                                    for ($i = 1; $i <= $count; $i++) {
                                        $luck =  rand(1, 1000);
                                        $percent = $pd['percent'] * 10;
                                        $find_stock = dd_q("SELECT * FROM box_stock WHERE p_id = ? ", [$pd['id']]);
                                        $upt = dd_q("UPDATE users SET point = point - ? WHERE id = ? ", [$all_price / $count, $_SESSION['id']]);

                                        if ($luck > $percent and $find_stock->rowCount() > 0) {
                                            $find_stock = dd_q("SELECT * FROM box_stock WHERE p_id = ?  LIMIT 1", [$pd['id']]);
                                            $stock = $find_stock->fetch(PDO::FETCH_ASSOC);
                                            $insert = dd_q("INSERT INTO boxlog (date , username , category , price , prize_name , uid)
                                                VALUES ( NOW() , ? , ? , ? , ? , ?  ) 
                                            ", [
                                                $row_1["username"],
                                                $pd["name"],
                                                $pd["price"],
                                                $stock["username"],
                                                $_SESSION['id']
                                            ]);
                                            $del = dd_q("DELETE FROM box_stock WHERE id = ? ", [$stock['id']]);
                                        } else {
                                            $insert = dd_q("INSERT INTO boxlog (date , username , category , price , prize_name , uid)
                                                VALUES ( NOW() , ? , ? , ? , ? , ?  ) 
                                            ", [
                                                $row_1["username"],
                                                $pd["name"],
                                                $pd["price"],
                                                $pd["salt_prize"],
                                                $_SESSION['id']
                                            ]);
                                        }
                                    }
                                    if ($insert) {
                                        $notifyPurchase();
                                        record_discount_usage($discount_id, $_SESSION['id'], $discount_amount);
                                        dd_return(true, true, "ซื้อสินค้าสำเร็จ !");
                                    } else {
                                        dd_return(false, "error", "[ERROR API BUY] โปรดติดต่อเจ้าของเว็บ!");
                                    }
                                } else {
                                    for ($i = 1; $i >= $count; $i++) {
                                        $upt = dd_q("UPDATE users SET point = point - ? WHERE id = ? ", [$all_price / $count, $_SESSION['id']]);
                                        $insert = dd_q("INSERT INTO boxlog (date , username , category , price , prize_name , uid)
                                            VALUES ( NOW() , ? , ? , ? , ? , ?  ) 
                                        ", [
                                            $row_1["username"],
                                            $pd["name"],
                                            $pd["price"],
                                            $pd["salt_prize"],
                                            $_SESSION['id']
                                        ]);
                                    }
                                    if ($insert) {
                                        $notifyPurchase();
                                        record_discount_usage($discount_id, $_SESSION['id'], $discount_amount);
                                        dd_return(true, true, "ซื้อสินค้าสำเร็จ !");
                                    } else {
                                        dd_return(false, "error", "[ERROR API BUY] โปรดติดต่อเจ้าของเว็บ!");
                                    }
                                }
                            } {
                                dd_return(false,  "error", "สินค้าในสต็อกไม่เพียงพอต่อการสั่งซื้อ");
                            }
                        } else {
                            dd_return(false,  "error", "เงินไม่เพียงพอ");
                        }
                    } else {
                        dd_return(false,  "error", "ไม่พบสินค้า");
                    }
                } else {
                    dd_return(false, "error",  "ไม่พบชื่อผู้ใช้งาน");
                }
            } else {
                dd_return(false, "error",  "สามารถซื้อสูงสุดได้ 100 ครั้งต่อรอบเท่านั้น");
            }
        } else {
            dd_return(false, "error",  "สามารถซื้อสูงสุดได้ 100 ครั้งเท่านั้น");
        }
    } else {
        dd_return(false, "error",  "เข้าสู่ระบบก่อนทำรายการ");
    }
} else {
    dd_return(false, "error",  "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");
}
