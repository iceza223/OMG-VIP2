<?php
require_once __DIR__ . '/system/a_func.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['id']) || !is_numeric($_SESSION['id'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'login_required' => true, 'message' => 'กรุณาเข้าสู่ระบบก่อนส่งข้อความถึงแอดมิน'], JSON_UNESCAPED_UNICODE);
    exit;
}

function contact_response(bool $ok, string $message, array $extra = []): never
{
    echo json_encode(array_merge(['ok' => $ok, 'message' => $message], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $conn->exec("CREATE TABLE IF NOT EXISTS admin_contacts (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        name VARCHAR(120) NOT NULL,
        contact VARCHAR(190) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('new','read','closed') NOT NULL DEFAULT 'new',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_admin_contacts_status (status),
        INDEX idx_admin_contacts_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        contact_response(false, 'Method ไม่ได้รับอนุญาต');
    }
    $name = trim((string)($_POST['name'] ?? ''));
    $contact = trim((string)($_POST['contact'] ?? ''));
    $message = trim((string)($_POST['message'] ?? ''));
    if ($name === '' || $contact === '' || $message === '') contact_response(false, 'กรุณากรอกข้อมูลให้ครบถ้วน');
    if (mb_strlen($name) > 120 || mb_strlen($contact) > 190 || mb_strlen($message) > 3000) contact_response(false, 'ข้อความยาวเกินกำหนด');
    if (!empty($_SESSION['contact_last_submit']) && time() - (int)$_SESSION['contact_last_submit'] < 20) {
        contact_response(false, 'กรุณารอสักครู่ก่อนส่งข้อความอีกครั้ง');
    }
    $userId = (int)$_SESSION['id'];
    $stmt = $conn->prepare('INSERT INTO admin_contacts (user_id, name, contact, message) VALUES (?, ?, ?, ?)');
    $stmt->execute([$userId, $name, $contact, $message]);
    $_SESSION['contact_last_submit'] = time();
    contact_response(true, 'ส่งข้อความถึงแอดมินเรียบร้อยแล้ว');
} catch (Throwable $e) {
    http_response_code(500);
    contact_response(false, 'ระบบติดต่อขัดข้องชั่วคราว');
}
