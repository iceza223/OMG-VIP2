<?php
// Admin PIN hash. Default PIN: 123456
$admin_pin_hash = '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92';
