<?php
require_once __DIR__ . '/../../system/a_func.php';
$conn->exec("CREATE TABLE IF NOT EXISTS admin_contacts (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    name VARCHAR(120) NOT NULL,
    contact VARCHAR(190) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('new','read','closed') NOT NULL DEFAULT 'new',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_admin_contacts_status (status),
    INDEX idx_admin_contacts_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_id'], $_POST['status'])) {
    $status = in_array($_POST['status'], ['new', 'read', 'closed'], true) ? $_POST['status'] : 'new';
    $stmt = $conn->prepare('UPDATE admin_contacts SET status=? WHERE id=?');
    $stmt->execute([$status, (int)$_POST['contact_id']]);
    echo '<script>location.href="?page=contact_messages";</script>';
    exit;
}
$rows = $conn->query('SELECT * FROM admin_contacts ORDER BY FIELD(status,"new","read","closed"), created_at DESC')->fetchAll(PDO::FETCH_ASSOC);
$countNew = (int)$conn->query("SELECT COUNT(*) FROM admin_contacts WHERE status='new'")->fetchColumn();
?>
<div class="p-3 p-lg-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div><h3 class="fw-bold mb-1"><i class="fa-solid fa-headset me-2"></i>ติดต่อแอดมิน</h3><p class="text-muted mb-0">ข้อความจากผู้ใช้และผู้เยี่ยมชมเว็บไซต์</p></div>
        <span class="badge bg-danger fs-6">ใหม่ <?= $countNew ?></span>
    </div>
    <?php if (!$rows): ?><div class="alert alert-light border">ยังไม่มีข้อความติดต่อ</div><?php endif; ?>
    <div class="table-responsive">
        <table class="table align-middle">
            <thead><tr><th>สถานะ</th><th>ผู้ติดต่อ</th><th>ช่องทางติดต่อ</th><th>ข้อความ</th><th>เวลา</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td><span class="badge <?= $row['status']==='new'?'bg-danger':($row['status']==='read'?'bg-warning text-dark':'bg-secondary') ?>"><?= $row['status']==='new'?'ใหม่':($row['status']==='read'?'อ่านแล้ว':'ปิดเรื่อง') ?></span></td>
                    <td><?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($row['contact'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td style="min-width:240px;white-space:pre-wrap"><?= htmlspecialchars($row['message'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td class="small text-muted"><?= htmlspecialchars($row['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><form method="post" class="d-flex gap-1"><input type="hidden" name="contact_id" value="<?= (int)$row['id'] ?>"><select name="status" class="form-select form-select-sm"><option value="new" <?= $row['status']==='new'?'selected':'' ?>>ใหม่</option><option value="read" <?= $row['status']==='read'?'selected':'' ?>>อ่านแล้ว</option><option value="closed" <?= $row['status']==='closed'?'selected':'' ?>>ปิดเรื่อง</option></select><button class="btn btn-sm btn-primary">บันทึก</button></form></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
