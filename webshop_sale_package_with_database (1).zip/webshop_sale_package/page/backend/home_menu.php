<?php
// Home menu card manager. The parent backend route already verifies admin access and PIN.
dd_q("CREATE TABLE IF NOT EXISTS home_nav_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(120) NOT NULL,
    icon VARCHAR(80) NOT NULL DEFAULT 'fa-circle',
    image_url VARCHAR(500) NOT NULL DEFAULT '',
    link VARCHAR(500) NOT NULL DEFAULT '?page=home',
    bg_color VARCHAR(20) NOT NULL DEFAULT '#102313',
    icon_color VARCHAR(20) NOT NULL DEFAULT '#b8d82e',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Upgrade tables created by the earlier version without breaking existing data.
$image_column_check = dd_q("SELECT COUNT(*) AS total FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'home_nav_items' AND COLUMN_NAME = 'image_url'");
$image_column_exists = $image_column_check ? (int)($image_column_check->fetch(PDO::FETCH_ASSOC)['total'] ?? 0) : 0;
if ($image_column_exists === 0) {
    dd_q("ALTER TABLE home_nav_items ADD COLUMN image_url VARCHAR(500) NOT NULL DEFAULT '' AFTER icon");
}

$seed_count = dd_q("SELECT COUNT(*) AS total FROM home_nav_items");
$seed_total = $seed_count ? (int)($seed_count->fetch(PDO::FETCH_ASSOC)['total'] ?? 0) : 0;
if ($seed_total === 0) {
    $seed = [
        ['เลือกซื้อสินค้า', 'fa-shop', '?page=shop', '#211a05', '#ffb300', 1, 1],
        ['เติมเงิน', 'fa-wallet', '?page=topup', '#06231a', '#66d63c', 1, 2],
        ['แลกโค้ด', 'fa-gift', '?page=redeem', '#210b12', '#ff4d6d', 1, 3],
        ['Download (THLIVE-MOD-FREE)', 'fa-download', '?page=download', '#211a05', '#ffb300', 1, 4],
        ['แจ้งโอนเงิน', 'fa-receipt', '?page=slip', '#071b24', '#7cff4d', 1, 5],
    ];
    foreach ($seed as $row) {
        dd_q("INSERT INTO home_nav_items (title, icon, link, bg_color, icon_color, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)", $row);
    }
}

$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['home_menu_save'])) {
    $ids = $_POST['id'] ?? [];
    $titles = $_POST['title'] ?? [];
    $icons = $_POST['icon'] ?? [];
    $images = $_POST['image_url'] ?? [];
    $links = $_POST['link'] ?? [];
    $bgs = $_POST['bg_color'] ?? [];
    $icon_colors = $_POST['icon_color'] ?? [];
    $active = $_POST['is_active'] ?? [];
    $orders = $_POST['sort_order'] ?? [];
    foreach ($ids as $i => $id) {
        $id = (int)$id;
        $title = trim((string)($titles[$i] ?? ''));
        $icon = trim((string)($icons[$i] ?? 'fa-circle'));
        $image_url = trim((string)($images[$i] ?? ''));
        $link = trim((string)($links[$i] ?? '?page=home'));
        $bg = trim((string)($bgs[$i] ?? '#102313'));
        $icon_color = trim((string)($icon_colors[$i] ?? '#b8d82e'));
        $order = (int)($orders[$i] ?? ($i + 1));
        if ($title === '') $title = 'เมนู';
        if (!preg_match('/^fa-[a-z0-9-]+$/i', $icon)) $icon = 'fa-circle';
        if ($image_url !== '' && (!filter_var($image_url, FILTER_VALIDATE_URL) || strlen($image_url) > 500)) $image_url = '';
        if (!preg_match('/^#[0-9a-f]{6}$/i', $bg)) $bg = '#102313';
        if (!preg_match('/^#[0-9a-f]{6}$/i', $icon_color)) $icon_color = '#b8d82e';
        if ($link === '' || strlen($link) > 500) $link = '?page=home';
        dd_q("UPDATE home_nav_items SET title=?, icon=?, image_url=?, link=?, bg_color=?, icon_color=?, is_active=?, sort_order=? WHERE id=?", [
            mb_substr($title, 0, 120), mb_substr($icon, 0, 80), mb_substr($image_url, 0, 500), $link, $bg, $icon_color, isset($active[$i]) ? 1 : 0, $order, $id
        ]);
    }
    $notice = 'บันทึกการตั้งค่าการ์ดเมนูแล้ว';
}

$items_result = dd_q("SELECT * FROM home_nav_items ORDER BY sort_order ASC, id ASC");
$items = $items_result ? $items_result->fetchAll(PDO::FETCH_ASSOC) : [];
?>
<div class="p-4 p-lg-5">
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-grid-2 text-xez-primary me-2"></i>การ์ดเมนูหน้าแรก</h3>
            <p class="text-muted mb-0">แก้ชื่อ ไอคอน ลิงก์ สี เปิด/ปิด และลำดับการ์ดเมนูบริการ</p>
        </div>
        <span class="badge rounded-pill bg-primary-soft text-xez-primary px-3 py-2"><?= count($items) ?> เมนู</span>
    </div>
    <?php if ($notice): ?><div class="alert alert-success"><?= htmlspecialchars($notice, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <form method="post">
        <input type="hidden" name="home_menu_save" value="1">
        <div class="table-responsive">
            <table class="table align-middle home-menu-table">
                <thead><tr><th>แสดง</th><th>ชื่อเมนู</th><th>ไอคอน Font Awesome</th><th>รูปภาพ (URL)</th><th>ลิงก์</th><th>พื้นหลัง</th><th>สีไอคอน</th><th>ลำดับ</th></tr></thead>
                <tbody>
                <?php foreach ($items as $index => $item): ?>
                    <tr>
                        <td><input type="hidden" name="id[]" value="<?= (int)$item['id'] ?>"><input class="form-check-input" type="checkbox" name="is_active[<?= $index ?>]" <?= ((int)$item['is_active'] === 1) ? 'checked' : '' ?>></td>
                        <td><input class="form-control" name="title[]" maxlength="120" value="<?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?>"></td>
                        <td><div class="input-group"><span class="input-group-text"><i class="fa-solid <?= htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') ?>"></i></span><input class="form-control" name="icon[]" value="<?= htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') ?>"></div></td>
                        <td><input class="form-control" name="image_url[]" maxlength="500" placeholder="https://.../image.jpg" value="<?= htmlspecialchars($item['image_url'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></td>
                        <td><input class="form-control" name="link[]" maxlength="500" value="<?= htmlspecialchars($item['link'], ENT_QUOTES, 'UTF-8') ?>"></td>
                        <td><input class="form-control form-control-color" type="color" name="bg_color[]" value="<?= htmlspecialchars($item['bg_color'], ENT_QUOTES, 'UTF-8') ?>" title="สีพื้นหลัง"></td>
                        <td><input class="form-control form-control-color" type="color" name="icon_color[]" value="<?= htmlspecialchars($item['icon_color'], ENT_QUOTES, 'UTF-8') ?>" title="สีไอคอน"></td>
                        <td><input class="form-control" type="number" name="sort_order[]" min="0" max="999" value="<?= (int)$item['sort_order'] ?>"></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="small text-muted mb-3">ใส่ URL รูปภาพเพื่อให้การ์ดแสดงรูปแทนไอคอนได้ ถ้าเว้นว่างจะใช้ไอคอน Font Awesome | ไอคอนใช้ชื่อ Font Awesome เช่น <code>fa-shop</code>, <code>fa-wallet</code>, <code>fa-gift</code> และลิงก์ใช้รูปแบบ <code>?page=shop</code> หรือ URL ภายนอก</div>
        <button class="btn btn-primary px-4" type="submit"><i class="fa-solid fa-floppy-disk me-2"></i>บันทึกเมนู</button>
    </form>
</div>
<style>
.home-menu-table th { white-space: nowrap; color: var(--text-muted) !important; }
.home-menu-table td { min-width: 110px; }
.home-menu-table td:nth-child(2) { min-width: 180px; }
.home-menu-table td:nth-child(4) { min-width: 230px; }
.form-control-color { width: 54px !important; min-width: 54px !important; height: 42px; padding: 4px !important; }
</style>
