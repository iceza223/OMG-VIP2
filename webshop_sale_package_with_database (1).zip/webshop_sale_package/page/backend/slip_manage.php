<?php $bank = dd_q("SELECT * FROM bank WHERE 1")->fetch(PDO::FETCH_ASSOC); ?>
<div class="p-4 p-lg-5">
    <div class="mb-5">
        <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-receipt text-xdvz-primary me-2"></i>
            จัดการระบบตรวจสอบสลิป</h3>
        <p class="text-muted small">ตั้งค่าข้อมูลบัญชีธนาคารเพื่อใช้ในการตรวจสอบชื่อผู้รับโอนเงิน</p>
    </div>

    <div class="row g-4">
        <div class="col-lg-7">
            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">ธนาคาร (Bank Name)</label>
                <select id="tname" class="form-select py-3 mb-4" style="border-radius: 12px;">
                    <option value="กสิกรไทย" <?php echo ($bank['tname'] == 'กสิกรไทย') ? 'selected' : ''; ?>>
                        ธนาคารกสิกรไทย (K-Bank)</option>
                    <option value="ไทยพาณิชย์" <?php echo ($bank['tname'] == 'ไทยพาณิชย์') ? 'selected' : ''; ?>>
                        ธนาคารไทยพาณิชย์ (SCB)</option>
                    <option value="ออมสิน" <?php echo ($bank['tname'] == 'ออมสิน') ? 'selected' : ''; ?>>ธนาคารออมสิน
                        (GSB)</option>
                    <option value="กรุงไทย" <?php echo ($bank['tname'] == 'กรุงไทย') ? 'selected' : ''; ?>>ธนาคารกรุงไทย
                        (Krungthai)</option>
                    <option value="ทหารไทยธนชาต" <?php echo ($bank['tname'] == 'ทหารไทยธนชาต') ? 'selected' : ''; ?>>
                        ธนาคารทหารไทยธนชาต (ttb)</option>
                    <option value="กรุงเทพ" <?php echo ($bank['tname'] == 'กรุงเทพ') ? 'selected' : ''; ?>>ธนาคารกรุงเทพ
                        (BBL)</option>
                    <option value="กรุงศรี" <?php echo ($bank['tname'] == 'กรุงศรี') ? 'selected' : ''; ?>>ธนาคารกรุงศรี
                        (BAY)</option>
                </select>

                <label class="form-label text-dark fw-bold small">ชื่อจริง (Recipient First Name)</label>
                <input type="text" id="fname" class="form-control py-3" value="<?php echo $bank['fname']; ?>"
                    placeholder="เช่น สมชาย" style="border-radius: 12px;">
                <div class="form-text text-muted small mt-2">โปรดระบุชื่อจริงให้ตรงกับบัญชีธนาคาร (ไม่ต้องมี นาย/นางสาว)
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">นามสกุล (Recipient Last Name)</label>
                <input type="text" id="lname" class="form-control py-3" value="<?php echo $bank['lname']; ?>"
                    placeholder="เช่น เจริญพร" style="border-radius: 12px;">
            </div>

            <div class="mb-5">
                <label class="form-label text-dark fw-bold small">เลขบัญชีธนาคาร (Account Number)</label>
                <input type="text" id="bnum" class="form-control py-3" value="<?php echo $bank['bnum']; ?>"
                    placeholder="เช่น 123-4-56789-0" style="border-radius: 12px;">
                <div class="form-text text-muted small mt-2">เลขบัญชีที่ต้องการให้ลูกค้าโอนเข้า</div>
            </div>

            <div class="mb-5">
                <label class="form-label text-dark fw-bold small">เบอร์ PromptPay / เลขบัตรประชาชน</label>
                <input type="text" id="promptpay_id" class="form-control py-3"
                    value="<?php echo $bank['promptpay_id'] ?? $bank['bnum']; ?>" placeholder="เช่น 081-234-5678"
                    style="border-radius: 12px;">
                <div class="form-text text-muted small mt-2">ใช้สำหรับสร้าง QR Code (หากไม่ระบุจะใช้เลขบัญชีแทน)</div>
            </div>

            <button class="btn btn-primary w-100 py-3 fw-bold shadow btn-topup-confirm" id="btn_save_bank">
                <i class="fa-solid fa-save me-2"></i> บันทึกข้อมูลธนาคาร
            </button>
        </div>

        <div class="col-lg-5">
            <div class="p-4 bg-light rounded-4 border">
                <h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-circle-info me-2 text-xdvz-primary"></i>
                    วิธีการใช้งาน</h6>
                <ul class="text-muted small ps-3 mb-0">
                    <li class="mb-2">ระบบจะนำ **ชื่อ** และ **นามสกุล** ไปตรวจสอบกับภาพสลิปที่ลูกค้าอัพโหลด</li>
                    <li class="mb-2">หากชื่อผู้รับโอนไม่ตรงกับที่ระบุไว้ ระบบจะไม่อนุมัติการเติมเงิน</li>
                    <li class="mb-0 text-danger fw-bold">ห้ามใส่คำนำหน้าชื่อเด็ดขาด (นาย/นาง/น.ส.)</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $("#btn_save_bank").click(function (e) {
        e.preventDefault();
        var formData = new FormData();
        formData.append('fname', $("#fname").val());
        formData.append('lname', $("#lname").val());
        formData.append('bnum', $("#bnum").val());
        formData.append('tname', $("#tname").val());
        formData.append('promptpay_id', $("#promptpay_id").val());

        Swal.fire({
            title: 'กำลังบันทึก...',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading() }
        });

        $.ajax({
            type: 'POST',
            url: 'system/backend/slip_manage.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            Swal.fire({
                icon: 'success',
                title: 'สำเร็จ',
                text: res.message
            }).then(() => window.location.reload());
        }).fail(function (jqXHR) {
            let res = jqXHR.responseJSON;
            Swal.fire({ icon: 'error', title: 'ผิดพลาด', text: res ? res.message : 'เกิดข้อผิดพลาดในการบันทึกข้อมูล' });
        });
    });
</script>