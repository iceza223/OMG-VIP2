<?php
$bank = dd_q("SELECT * FROM bank WHERE 1")->fetch(PDO::FETCH_ASSOC);
$pp_id = !empty($bank['promptpay_id']) ? $bank['promptpay_id'] : $bank['bnum'];
$recipient_name = trim(($bank['fname'] ?? '') . ' ' . ($bank['lname'] ?? ''));
?>
<div class="container-sm mt-4">
    <div class="xez-card p-4">
        <div class="mb-4">
            <h4 class="fw-bold mb-1 text-dark"><i class="fa-solid fa-qrcode text-success me-2"></i> PromptPay QR</h4>
            <p class="text-secondary small">สแกน QR Code เพื่อชำระเงิน และแนบสลิปเพื่อตรวจสอบทันที</p>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-6">
                <!-- Config Card -->
                <div class="card border-0 bg-light rounded-4 p-4 mb-4">
                    <div class="mb-3">
                        <label class="form-label text-muted small">เบอร์โทรศัพท์ / เลขบัตรประชาชน (PromptPay ID)</label>
                        <input type="text" class="form-control text-center fw-bold fs-5" value="<?= $pp_id ?>" readonly
                            disabled>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted small">จำนวนเงินที่ต้องการเติม</label>
                        <input type="number" id="promptpay_amount"
                            class="form-control text-center py-3 fs-4 fw-bold text-success" placeholder="0.00">
                    </div>

                    <button class="btn btn-success w-100 py-3 fw-bold rounded-pill" onclick="generateQR()">
                        <i class="fa-solid fa-qrcode me-2"></i> สร้าง QR Code
                    </button>
                    <p class="text-danger small mt-2 text-center">* กรุณาตรวจสอบชื่อผู้รับโอนให้ถูกต้องก่อนโอนเงิน</p>
                </div>
            </div>

            <div class="col-lg-6 text-center" id="qr_result" style="display: none;">
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4 text-center">
                    <h5 class="fw-bold text-dark mb-3">สแกนเพื่อจ่ายเงิน</h5>
                    <img id="qr_image" src="" class="img-fluid rounded-3 mb-3" style="max-width: 250px;">
                    <h4 class="fw-bold text-success mb-0" id="display_amount">0.00 ฿</h4>
                    <p class="text-muted small mt-2">ชื่อบัญชี: <?= htmlspecialchars($recipient_name) ?></p>
                </div>

                <!-- Upload Zone (Hidden initially, shown after QR generated? Or always there?) -->
                <!-- Let's show it, but make it clear it's for after transfer -->

                <div class="upload-zone border-dashed rounded-4 p-4 text-center mb-4 cursor-pointer" id="dropZone"
                    onclick="$('#slipInput').click()">
                    <div id="uploadPlaceholder">
                        <i class="fa-solid fa-cloud-arrow-up text-success display-4 mb-3"></i>
                        <h5 class="fw-bold text-dark">แนบไฟล์สลิปการโอนเงินที่นี่</h5>
                        <p class="text-muted small">รองรับไฟล์ภาพ JPG, PNG (ขนาดไม่เกิน 5MB)</p>
                    </div>
                    <div id="previewZone" class="d-none">
                        <img id="slipPreview" class="img-fluid rounded-3 shadow-sm mb-3" style="max-height: 200px;">
                        <p class="text-muted small">คลิกเพื่อเปลี่ยนรูปสลิป</p>
                    </div>
                    <input type="file" id="slipInput" accept="image/*" class="d-none">
                </div>

                <div id="processing" class="text-center d-none mb-4">
                    <div class="spinner-border text-success mb-2" role="status"></div>
                    <p class="text-muted small mb-0">กำลังอ่านข้อมูลสลิปและตรวจสอบชื่อ...</p>
                </div>

                <div id="resultCard" class="card border-0 bg-light-soft rounded-4 p-4 d-none mb-4">
                    <h6 class="fw-bold text-dark mb-4 text-center"><i class="fa-solid fa-receipt me-2"></i> ผลการตรวจสอบ
                    </h6>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <div class="p-2 bg-white rounded-3 border text-center">
                                <p class="text-muted x-small mb-1">ยอดเงินในสลิป</p>
                                <h5 class="fw-bold text-dark mb-0" id="resultAmount">-</h5>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-2 bg-white rounded-3 border text-center">
                                <p class="text-muted x-small mb-1">สถานะ</p>
                                <h5 class="fw-bold mb-0" id="resultRecipientStatus">-</h5>
                            </div>
                        </div>
                    </div>

                    <p class="text-muted x-small mb-1 text-start">Ref ID:</p>
                    <p class="fw-medium text-dark mb-3 small text-start bg-white p-2 rounded border" id="resultRef">-
                    </p>

                    <button class="btn btn-success w-100 py-3 fw-bold rounded-pill" id="confirmBtn" disabled>
                        <i class="fa-solid fa-check-circle me-2"></i> ยืนยันการเติมเงิน
                    </button>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
<script>
    const expectedName = "<?= $recipient_name ?>";
    let extractedData = {};

    function generateQR() {
        let pp_id = "<?= preg_replace('/[^0-9]/', '', $pp_id) ?>";
        let amount = parseFloat($("#promptpay_amount").val());

        if (!amount || amount <= 0) {
            Swal.fire({
                icon: 'warning',
                title: 'กรุณาระบุจำนวนเงิน',
                text: 'จำนวนเงินต้องมากกว่า 0'
            });
            return;
        }

        let qr_url = "https://promptpay.io/" + pp_id + "/" + amount;

        $("#qr_image").attr("src", qr_url);
        $("#display_amount").text(amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ฿');
        $("#qr_result").slideDown();

        // Auto scroll to result
        $('html, body').animate({
            scrollTop: $("#qr_result").offset().top
        }, 500);
    }

    $("#slipInput").change(async function (e) {
        if (!e.target.files.length) return;
        const file = e.target.files[0];
        const imageUrl = URL.createObjectURL(file);

        // Show preview
        $("#slipPreview").attr("src", imageUrl);
        $("#uploadPlaceholder").addClass("d-none");
        $("#previewZone").removeClass("d-none");

        $("#processing").removeClass("d-none");
        $("#resultCard").addClass("d-none");

        try {
            const worker = await Tesseract.createWorker('tha+eng');
            const result = await worker.recognize(imageUrl);

            const textRaw = result.data.text;
            const text = textRaw.replace(/[^a-zA-Z0-9\u0E00-\u0E7F\.]/g, '');
            console.log("OCR Cleaned:", text);

            // 1. Extract Amount
            const textForAmount = textRaw.replace(/[^0-9\.]/g, ' ');
            const amountMatches = textForAmount.match(/(\d+\.\d{2})/g);
            let amount = 0;
            if (amountMatches) {
                amount = Math.max(...amountMatches.map(m => parseFloat(m)));
            }

            // 2. Extract Reference ID
            const refMatch = text.match(/[0-9A-Z]{10,25}/g);
            let ref = '';
            if (refMatch) {
                ref = refMatch.reduce((a, b) => a.length > b.length ? a : b, '');
            }

            // 3. Name Check (Strict)
            const cleanExpected = expectedName.replace(/[^a-zA-Z0-9\u0E00-\u0E7F]/g, '');
            const checkText = textRaw.replace(/[^a-zA-Z0-9\u0E00-\u0E7F]/g, '');
            const nameMatched = checkText.includes(cleanExpected);

            extractedData = {
                amount: amount,
                ref: ref,
                nameMatched: nameMatched,
                file: file
            };

            // Update UI
            $("#resultAmount").text(extractedData.amount > 0 ? extractedData.amount.toLocaleString(undefined, { minimumFractionDigits: 2 }) + ' ฿' : 'ค้นหาไม่พบ');
            $("#resultRef").text(extractedData.ref ? extractedData.ref : 'ค้นหาไม่พบ');

            const statusTarget = $("#resultRecipientStatus");
            if (nameMatched) {
                statusTarget.html('<i class="fa-solid fa-circle-check text-success me-1"></i> ถูกต้อง').addClass("text-success").removeClass("text-danger");
                $("#confirmBtn").prop("disabled", false);
            } else {
                statusTarget.html('<i class="fa-solid fa-circle-xmark text-danger me-1"></i> ไม่พบชื่อผู้รับ').addClass("text-danger").removeClass("text-success");
                $("#confirmBtn").prop("disabled", true);

                let debugMsg = `<br><small class='text-muted'>ชื่อในระบบ: ${expectedName}</small>`;
                Swal.fire({
                    icon: 'error',
                    title: 'ชื่อผู้รับเงินไม่ถูกต้อง',
                    html: `ไม่พบชื่อผู้รับเงินที่ถูกต้องในสลิป ${debugMsg}`
                });
            }

            $("#processing").addClass("d-none");
            $("#resultCard").removeClass("d-none");

            await worker.terminate();

            // Handle Missing Data Fallback
            if (nameMatched) {
                if (extractedData.amount <= 0) {
                    const { value: manualAmount } = await Swal.fire({
                        title: 'ระบุจำนวนเงิน', text: 'ระบบอ่านจำนวนเงินไม่ได้ กรุณาระบุ',
                        input: 'number', inputAttributes: { min: 1, step: 0.01 }, confirmButtonText: 'ยืนยัน', allowOutsideClick: false
                    });
                    if (manualAmount) {
                        extractedData.amount = parseFloat(manualAmount);
                        $("#resultAmount").text(extractedData.amount.toLocaleString() + ' ฿');
                    }
                }

                if (!extractedData.ref) {
                    const { value: manualRef } = await Swal.fire({
                        title: 'ระบุเลขอ้างอิง', text: 'ระบบอ่านเลขอ้างอิงไม่ได้ กรุณาระบุ',
                        input: 'text', confirmButtonText: 'ยืนยัน', allowOutsideClick: false
                    });
                    if (manualRef) {
                        extractedData.ref = manualRef;
                        $("#resultRef").text(extractedData.ref);
                    }
                }
            }

        } catch (error) {
            $("#processing").addClass("d-none");
            Swal.fire({ icon: 'error', title: 'เกิดข้อผิดพลาดในการอ่านสลิป' });
            console.error(error);
        }
    });

    // Drag & Drop
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('slipInput');

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('bg-light-soft');
        dropZone.style.borderColor = '#198754'; // Success green
    });

    dropZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropZone.classList.remove('bg-light-soft');
        dropZone.style.borderColor = '#dee2e6';
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('bg-light-soft');
        dropZone.style.borderColor = '#dee2e6';
        if (e.dataTransfer.files.length) {
            fileInput.files = e.dataTransfer.files;
            $("#slipInput").trigger("change");
        }
    });

    $("#confirmBtn").click(function () {
        if (extractedData.amount <= 0 || !extractedData.ref) {
            Swal.fire({ icon: 'warning', title: 'ข้อมูลไม่ครบถ้วน' });
            return;
        }

        Swal.fire({ title: 'กำลังตรวจสอบ...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

        const formData = new FormData();
        formData.append('amount', extractedData.amount);
        formData.append('ref', extractedData.ref);
        formData.append('slip_image', extractedData.file);

        $.ajax({
            type: 'POST',
            url: 'system/slip.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            if (res.status == 'success') {
                Swal.fire({ icon: 'success', title: 'สำเร็จ!', text: res.message }).then(() => location.href = '?page=home');
            } else {
                Swal.fire({ icon: 'error', title: 'ไม่สามารถเติมเงินได้', text: res.message });
            }
        }).fail(function (jqXHR) {
            let res = jqXHR.responseJSON;
            Swal.fire({ icon: 'error', title: 'ระบบขัดข้อง', text: res ? res.message : 'เกิดข้อผิดพลาด' });
        });
    });
</script>

<style>
    .cursor-pointer {
        cursor: pointer;
    }

    .upload-zone {
        transition: all 0.2s ease-in-out;
        background: rgba(25, 135, 84, 0.02);
    }

    .upload-zone:hover {
        background: rgba(25, 135, 84, 0.05);
        border-color: #198754 !important;
        /* Success green */
    }

    .bg-light-soft {
        background-color: rgba(25, 135, 84, 0.05) !important;
    }

    .border-dashed {
        border: 2px dashed #dee2e6 !important;
    }

    /* Override primary text to success green for this page context if needed, or use text-success */
</style>