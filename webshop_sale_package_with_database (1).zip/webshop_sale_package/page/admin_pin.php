<div class="p-4 p-lg-5">
    <div class="mb-4">
        <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-lock text-xdvz-primary me-2"></i> เปลี่ยน PIN หลังบ้าน</h3>
        <p class="text-muted small mb-0">เปลี่ยนรหัส PIN 6 หลักที่ใช้ก่อนเข้าสู่ระบบหลังบ้าน</p>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="p-4 rounded-4 bg-light border">
                <div class="mb-3">
                    <label class="form-label fw-bold">PIN ปัจจุบัน</label>
                    <input type="password" id="current_pin" class="form-control form-control-lg" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="current-password">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">PIN ใหม่</label>
                    <input type="password" id="new_pin" class="form-control form-control-lg" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="new-password">
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold">ยืนยัน PIN ใหม่</label>
                    <input type="password" id="confirm_pin" class="form-control form-control-lg" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="new-password">
                </div>
                <button type="button" id="save_admin_pin" class="btn xdvz-btn-cyan w-100 py-3 fw-bold">บันทึก PIN ใหม่</button>
            </div>
        </div>
    </div>
</div>
<script>
$('#save_admin_pin').on('click', function () {
    const current = $('#current_pin').val().trim();
    const next = $('#new_pin').val().trim();
    const confirm = $('#confirm_pin').val().trim();
    if (!/^\d{6}$/.test(current) || !/^\d{6}$/.test(next) || !/^\d{6}$/.test(confirm)) {
        Swal.fire({icon: 'warning', title: 'ข้อมูลไม่ครบ', text: 'กรุณากรอก PIN เป็นตัวเลข 6 หลักทุกช่อง'});
        return;
    }
    if (next !== confirm) {
        Swal.fire({icon: 'warning', title: 'PIN ไม่ตรงกัน', text: 'กรุณากรอก PIN ใหม่ให้ตรงกัน'});
        return;
    }
    $.post('system/backend/admin_pin_change.php', {current_pin: current, new_pin: next, confirm_pin: confirm})
        .done(function (res) {
            Swal.fire({icon: 'success', title: 'สำเร็จ', text: res.message}).then(() => window.location.href = '?page=backend');
        })
        .fail(function (xhr) {
            const res = xhr.responseJSON || {};
            Swal.fire({icon: 'error', title: 'ไม่สำเร็จ', text: res.message || 'ไม่สามารถเปลี่ยน PIN ได้'});
        });
});
</script>
