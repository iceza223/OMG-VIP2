<?php
$topup_gift_enabled = (($config['topup_gift_status'] ?? 'on') === 'on');
$topup_redeem_enabled = (($config['topup_redeem_status'] ?? 'on') === 'on');
$topup_slip_enabled = (($config['topup_slip_status'] ?? 'on') === 'on');
$topup_promptpay_enabled = (($config['topup_promptpay_status'] ?? 'on') === 'on');
$topup_card_enabled = (($config['topup_card_status'] ?? 'on') === 'on');
?>
<?php if (!isset($_GET['sub'])): ?>
    <div class="container-sm mt-4">
        <div class="mb-4">
            <h2 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-wallet text-xez-primary me-2"></i> Payment Methods
            </h2>
            <p class="text-muted small">หน้าหลัก > เติมเงิน</p>
        </div>

        <div class="row g-4 justify-content-center">
            <?php if ($topup_gift_enabled): ?>
            <!-- TrueMoney Gift -->
            <div class="col-12 col-md-4">
                <a href="?page=topup&sub=gift" class="text-decoration-none">
                    <div class="xez-card h-100 d-flex align-items-center p-3">
                        <div class="bg-dark rounded-3 p-3 me-3"
                            style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <img src="assets/img/truemoney.png" class="img-fluid truemoney-card-image"
                                alt="TrueMoney">
                        </div>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold text-dark mb-0">TrueMoney</h5>
                            <p class="text-muted x-small mb-1">ซองของขวัญอั่งเปา</p>
                            <span class="badge bg-success-soft text-success small">ปกติ</span>
                        </div>
                    </div>
                </a>
            </div>

            <?php endif; ?>

            <?php if ($topup_card_enabled): ?>
            <!-- TrueMoney 14-digit card: manual admin review -->
            <div class="col-12 col-md-4">
                <a href="?page=topup&sub=card" class="text-decoration-none">
                    <div class="xez-card h-100 d-flex align-items-center p-3">
                        <div class="bg-dark rounded-3 p-3 me-3" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <i class="fa-solid fa-credit-card text-warning display-6"></i>
                        </div>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold text-dark mb-0">บัตร TrueMoney</h5>
                            <p class="text-muted x-small mb-1">บัตร 14 หลัก รอแอดมินอนุมัติ</p>
                            <span class="badge bg-warning text-dark small">ภายใน 24 ชม.</span>
                        </div>
                    </div>
                </a>
            </div>
            <?php endif; ?>

            <?php if ($topup_redeem_enabled): ?>
            <!-- Redeem -->
            <div class="col-12 col-md-4">
                <a href="?page=redeem" class="text-decoration-none">
                    <div class="xez-card h-100 d-flex align-items-center p-3">
                        <div class="bg-dark rounded-3 p-3 me-3"
                            style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <img src="/assets/redeem-icon.png" class="img-fluid" alt="Redeem">
                        </div>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold text-dark mb-0">Redeem</h5>
                            <p class="text-muted x-small mb-1">กิ๊ฟโค๊ตจากเว็บไซต์</p>
                            <span class="badge bg-success-soft text-success small">ปกติ</span>
                        </div>
                    </div>
                </a>
            </div>

            <?php endif; ?>

            <?php if ($topup_slip_enabled): ?>
            <!-- Slip Check -->
            <div class="col-12 col-md-4">
                <a href="?page=slip" class="text-decoration-none">
                    <div class="xez-card h-100 d-flex align-items-center p-3">
                        <div class="bg-dark rounded-3 p-3 me-3"
                            style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <img src="https://img5.pic.in.th/file/secure-sv1/slip.webp" class="img-fluid" alt="Slip">
                        </div>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold text-dark mb-0">SLIP CHECK</h5>
                            <p class="text-muted x-small mb-1">แนบสลิปการโอนเงิน</p>
                            <span class="badge bg-success-soft text-success small">ปกติ</span>
                        </div>
                    </div>
                </a>
            </div>

            <?php endif; ?>

            <?php if ($topup_promptpay_enabled): ?>
            <!-- PromptPay QR -->
            <div class="col-12 col-md-4">
                <a href="?page=topup&sub=promptpay" class="text-decoration-none">
                    <div class="xez-card h-100 d-flex align-items-center p-3">
                        <div class="bg-dark rounded-3 p-3 me-3"
                            style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXwvGngc1UzYjIpR9vQOUmqQoNLhwK30eptdsBu-CbpA&s"
                                class="img-fluid" alt="PromptPay">
                        </div>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold text-dark mb-0">PromptPay QR</h5>
                            <p class="text-muted x-small mb-1">สแกนจ่ายผ่าน QR</p>
                            <span class="badge bg-success-soft text-success small">แนะนำ</span>
                        </div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php if (!$topup_gift_enabled && !$topup_redeem_enabled && !$topup_slip_enabled && !$topup_promptpay_enabled && !$topup_card_enabled): ?>
            <div class="alert alert-warning text-center mt-4">ขณะนี้ยังไม่มีช่องทางเติมเงินที่เปิดให้บริการ</div>
        <?php endif; ?>
    </div>
<?php else: ?>
    <?php
    if ($_GET['sub'] == "card" && $topup_card_enabled) {
        require_once('page/topup_card.php');
    } elseif ($_GET['sub'] == "gift" && $topup_gift_enabled) {
        require_once('page/topup_gift.php');
    } elseif ($_GET['sub'] == "promptpay" && $topup_promptpay_enabled) {
        require_once('page/topup_promptpay.php');
    } else { ?>
        <div class="container-sm mt-5">
            <div class="alert alert-warning text-center">ช่องทางเติมเงินนี้ถูกปิดให้บริการชั่วคราว</div>
            <div class="text-center"><a class="btn btn-outline-primary" href="?page=topup">กลับไปเลือกช่องทางเติมเงิน</a></div>
        </div>
    <?php }
    ?>

<?php endif; ?>

<style>
    .bg-success-soft {
        background-color: rgba(25, 135, 84, 0.1);
    }

    .x-small {
        font-size: 0.75rem;
    }

    .truemoney-card-image {
        width: 100%;
        height: 100%;
        object-fit: contain;
        object-position: center;
    }
</style>
