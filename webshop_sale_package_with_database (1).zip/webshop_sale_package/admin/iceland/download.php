<?php

declare(strict_types=1);

session_start();
require_once __DIR__ . '/config.php';

if (empty($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    exit('ไม่มีสิทธิ์เข้าถึง');
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    http_response_code(400);
    exit('รหัสไฟล์ไม่ถูกต้อง');
}

$stmt = $pdo->prepare('SELECT filename, original_name, filetype, filesize FROM files WHERE id = ?');
$stmt->execute([$id]);
$file = $stmt->fetch();

if (!$file) {
    http_response_code(404);
    exit('ไม่พบไฟล์');
}

$filename = basename((string)$file['filename']);
$path = UPLOAD_DIR . $filename;
$basePath = realpath(UPLOAD_DIR);
$realPath = is_file($path) ? realpath($path) : false;

if ($basePath === false || $realPath === false || dirname($realPath) !== rtrim($basePath, DIRECTORY_SEPARATOR)) {
    http_response_code(404);
    exit('ไม่พบไฟล์บนเซิร์ฟเวอร์');
}

$downloadName = (string)($file['original_name'] ?: $filename);
$downloadName = basename($downloadName);
$mime = (string)($file['filetype'] ?: 'application/octet-stream');

if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9!#$&^_.+-]*\/[a-zA-Z0-9][a-zA-Z0-9!#$&^_.+-]*$/', $mime)) {
    $mime = 'application/octet-stream';
}

header('Content-Description: File Transfer');
header('Content-Type: ' . $mime);
header('Content-Disposition: attachment; filename="' . addcslashes($downloadName, "\\\"") . '"');
header('Content-Length: ' . (string)filesize($realPath));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');

readfile($realPath);
exit;
