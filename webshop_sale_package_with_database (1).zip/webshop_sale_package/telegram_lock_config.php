<?php
// Configure these per customer if Telegram lock is used.
const TELEGRAM_BOT_TOKEN = '';
const TELEGRAM_WEBHOOK_SECRET = '';
const TELEGRAM_LOCK_STATE_FILE = __DIR__ . '/system/telegram_lock_state.json';
