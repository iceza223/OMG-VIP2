<?php
declare(strict_types=1);

final class DiscordWebhook
{
    public function __construct(private readonly string $url, private readonly string $username = 'เว็บไซต์ OMGVIP')
    {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if (!filter_var($url, FILTER_VALIDATE_URL) || !in_array($host, ['discord.com', 'discordapp.com'], true)) {
            throw new InvalidArgumentException('Invalid Discord webhook URL.');
        }
    }

    public function sendEmbed(string $title, string $description, array $fields = [], int $color = 5763719): void
    {
        $embed = [
            'title' => $this->clip($title, 256),
            'description' => $this->clip($description, 4096),
            'color' => max(0, min($color, 16777215)),
            'timestamp' => gmdate('c'),
            'footer' => ['text' => 'OMGVIP Website'],
        ];
        if ($fields) {
            $embed['fields'] = array_map(fn(array $f) => [
                'name' => $this->clip((string)($f['name'] ?? 'ข้อมูล'), 256),
                'value' => $this->clip((string)($f['value'] ?? '-'), 1024),
                'inline' => (bool)($f['inline'] ?? false),
            ], array_slice($fields, 0, 25));
        }
        $payload = json_encode([
            'username' => $this->clip($this->username, 80),
            'embeds' => [$embed],
            'allowed_mentions' => ['parse' => []],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);

        $ch = curl_init($this->url . '?wait=false');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'User-Agent: OMGVIP-Website/1.0'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 10,
        ]);
        $response = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($response === false) throw new RuntimeException('Discord connection failed: ' . $error);
        if ($status === 429) throw new RuntimeException('Discord rate limit reached.');
        if ($status < 200 || $status >= 300) throw new RuntimeException('Discord rejected webhook: HTTP ' . $status);
    }

    private function clip(string $value, int $max): string
    {
        $value = trim(preg_replace('/[\x00-\x1F\x7F]/u', '', $value) ?? '');
        return function_exists('mb_substr') ? mb_substr($value, 0, $max, 'UTF-8') : substr($value, 0, $max);
    }
}

function jsonResponse(int $status, array $body): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function requestData(): array
{
    if (str_contains(strtolower((string)($_SERVER['CONTENT_TYPE'] ?? '')), 'application/json')) {
        $data = json_decode(file_get_contents('php://input') ?: '', true);
        if (!is_array($data)) throw new InvalidArgumentException('Invalid JSON body.');
        return $data;
    }
    return is_array($_POST) ? $_POST : [];
}

function cleanText(mixed $value, int $max = 1000): string
{
    $text = trim((string)$value);
    $text = str_replace(['@everyone', '@here'], ['@ everyone', '@ here'], $text);
    $text = preg_replace('/[\x00-\x1F\x7F]/u', '', $text) ?? '';
    return function_exists('mb_substr') ? mb_substr($text, 0, $max, 'UTF-8') : substr($text, 0, $max);
}
