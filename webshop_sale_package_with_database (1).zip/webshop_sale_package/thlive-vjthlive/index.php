<?php
// THLIVE entry point for thlive.omgvip.shop
header('Location: index.html', true, 302);
exit;
