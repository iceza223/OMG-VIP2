/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: webshop_sale
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_chat_messages`
--

DROP TABLE IF EXISTS `admin_chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_chat_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `sender` enum('user','admin') NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_read_at` timestamp NULL DEFAULT NULL,
  `user_read_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_chat_user_created` (`user_id`,`created_at`),
  KEY `idx_chat_sender` (`sender`),
  KEY `idx_chat_user_id` (`user_id`,`id`),
  KEY `idx_chat_admin_unread` (`sender`,`admin_read_at`),
  KEY `idx_chat_user_unread` (`user_id`,`sender`,`user_read_at`),
  KEY `idx_chat_user_admin_read` (`user_id`,`sender`,`admin_read_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_chat_messages`
--

LOCK TABLES `admin_chat_messages` WRITE;
/*!40000 ALTER TABLE `admin_chat_messages` DISABLE KEYS */;
INSERT INTO `admin_chat_messages` VALUES
(1,1,'user','เม','2026-09-30 18:30:25',NULL,NULL);
/*!40000 ALTER TABLE `admin_chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_contacts`
--

DROP TABLE IF EXISTS `admin_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `contact` varchar(190) NOT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','closed') NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_contact_status` (`status`),
  KEY `idx_contact_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_contacts`
--

LOCK TABLES `admin_contacts` WRITE;
/*!40000 ALTER TABLE `admin_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL DEFAULT '',
  `lname` varchar(100) NOT NULL DEFAULT '',
  `bnum` varchar(100) NOT NULL DEFAULT '',
  `tname` varchar(100) NOT NULL DEFAULT '',
  `promptpay_id` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES
(1,'','','','','');
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `box_product`
--

DROP TABLE IF EXISTS `box_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `box_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `des` text NOT NULL,
  `type` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `c_type` varchar(225) NOT NULL DEFAULT '',
  `percent` decimal(6,2) NOT NULL DEFAULT 0.00,
  `salt_prize` decimal(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `idx_product_category` (`c_type`),
  KEY `idx_product_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `box_product`
--

LOCK TABLES `box_product` WRITE;
/*!40000 ALTER TABLE `box_product` DISABLE KEYS */;
INSERT INTO `box_product` VALUES
(1,'เทส12','https://omgvip.shop/download/files/1cb415009efae00f_9d130c89-e11a-436a-8690-388a26b4a101.png',10.00,'12',1,'กลุ่ม',0.00,0.00);
/*!40000 ALTER TABLE `box_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `box_stock`
--

DROP TABLE IF EXISTS `box_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `box_stock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `p_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_stock_product` (`p_id`),
  CONSTRAINT `fk_stock_product` FOREIGN KEY (`p_id`) REFERENCES `box_product` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `box_stock`
--

LOCK TABLES `box_stock` WRITE;
/*!40000 ALTER TABLE `box_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `box_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boxlog`
--

DROP TABLE IF EXISTS `boxlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `boxlog` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `product_id` int(10) unsigned DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_boxlog_uid` (`uid`),
  KEY `idx_boxlog_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boxlog`
--

LOCK TABLES `boxlog` WRITE;
/*!40000 ALTER TABLE `boxlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `boxlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `byshop`
--

DROP TABLE IF EXISTS `byshop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `byshop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `apikey` varchar(255) NOT NULL DEFAULT '',
  `cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `byshop`
--

LOCK TABLES `byshop` WRITE;
/*!40000 ALTER TABLE `byshop` DISABLE KEYS */;
INSERT INTO `byshop` VALUES
(1,0,'',0.00);
/*!40000 ALTER TABLE `byshop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carousel`
--

DROP TABLE IF EXISTS `carousel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carousel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carousel`
--

LOCK TABLES `carousel` WRITE;
/*!40000 ALTER TABLE `carousel` DISABLE KEYS */;
/*!40000 ALTER TABLE `carousel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `c_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_name` varchar(225) NOT NULL,
  `des` text DEFAULT NULL,
  `img` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`c_id`),
  UNIQUE KEY `uq_category_name` (`c_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES
(1,'กลุ่ม','เ','https://omgvip.shop/download/files/1cb415009efae00f_9d130c89-e11a-436a-8690-388a26b4a101.png');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crecom`
--

DROP TABLE IF EXISTS `crecom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crecom` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recom_1` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_2` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crecom`
--

LOCK TABLES `crecom` WRITE;
/*!40000 ALTER TABLE `crecom` DISABLE KEYS */;
INSERT INTO `crecom` VALUES
(1,0,0);
/*!40000 ALTER TABLE `crecom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_codes`
--

DROP TABLE IF EXISTS `discount_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `discount_type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `discount_value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `min_purchase` decimal(10,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(10,2) DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes`
--

LOCK TABLES `discount_codes` WRITE;
/*!40000 ALTER TABLE `discount_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_usage`
--

DROP TABLE IF EXISTS `discount_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_usage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `used_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_discount_user` (`code_id`,`user_id`),
  KEY `idx_discount_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_usage`
--

LOCK TABLES `discount_usage` WRITE;
/*!40000 ALTER TABLE `discount_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_nav_items`
--

DROP TABLE IF EXISTS `home_nav_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `home_nav_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `icon` varchar(80) NOT NULL DEFAULT 'fa-circle',
  `image_url` varchar(500) NOT NULL DEFAULT '',
  `link` varchar(500) NOT NULL DEFAULT '?page=home',
  `bg_color` varchar(20) NOT NULL DEFAULT '#102313',
  `icon_color` varchar(20) NOT NULL DEFAULT '#b8d82e',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_nav_items`
--

LOCK TABLES `home_nav_items` WRITE;
/*!40000 ALTER TABLE `home_nav_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `home_nav_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kbank_trans`
--

DROP TABLE IF EXISTS `kbank_trans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kbank_trans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `qr` varchar(255) NOT NULL DEFAULT '',
  `ref` varchar(255) NOT NULL DEFAULT '',
  `sender` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_kbank_ref` (`ref`),
  KEY `idx_kbank_qr` (`qr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kbank_trans`
--

LOCK TABLES `kbank_trans` WRITE;
/*!40000 ALTER TABLE `kbank_trans` DISABLE KEYS */;
/*!40000 ALTER TABLE `kbank_trans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `popup_announcements`
--

DROP TABLE IF EXISTS `popup_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `popup_announcements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `button_text` varchar(100) NOT NULL DEFAULT 'ถัดไป',
  `button_link` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `show_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `popup_announcements`
--

LOCK TABLES `popup_announcements` WRITE;
/*!40000 ALTER TABLE `popup_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `popup_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recom`
--

DROP TABLE IF EXISTS `recom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recom` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recom_1` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_2` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_3` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_4` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_5` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_6` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_7` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_8` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_9` int(10) unsigned NOT NULL DEFAULT 0,
  `recom_10` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recom`
--

LOCK TABLES `recom` WRITE;
/*!40000 ALTER TABLE `recom` DISABLE KEYS */;
INSERT INTO `recom` VALUES
(1,0,0,0,0,0,0,0,0,0,0,1);
/*!40000 ALTER TABLE `recom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redeem`
--

DROP TABLE IF EXISTS `redeem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `redeem` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `prize` decimal(12,2) NOT NULL DEFAULT 0.00,
  `max_count` int(10) unsigned NOT NULL DEFAULT 1,
  `count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_redeem_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redeem`
--

LOCK TABLES `redeem` WRITE;
/*!40000 ALTER TABLE `redeem` DISABLE KEYS */;
/*!40000 ALTER TABLE `redeem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redeem_his`
--

DROP TABLE IF EXISTS `redeem_his`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `redeem_his` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `code` varchar(100) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_redeem_user_code` (`code`,`uid`),
  KEY `idx_redeem_his_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redeem_his`
--

LOCK TABLES `redeem_his` WRITE;
/*!40000 ALTER TABLE `redeem_his` DISABLE KEYS */;
/*!40000 ALTER TABLE `redeem_his` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT 'OMG SHOP',
  `logo` varchar(500) NOT NULL DEFAULT 'assets/omg-logo.png',
  `des` text DEFAULT NULL,
  `discord` varchar(500) NOT NULL DEFAULT '',
  `facebook` varchar(500) NOT NULL DEFAULT '',
  `line` varchar(500) NOT NULL DEFAULT '',
  `telegram` varchar(500) NOT NULL DEFAULT '',
  `telegram2` varchar(500) NOT NULL DEFAULT '',
  `wallet` varchar(100) NOT NULL DEFAULT '',
  `theme` varchar(50) NOT NULL DEFAULT 'dark',
  `announce` text DEFAULT NULL,
  `webhook` varchar(500) NOT NULL DEFAULT '',
  `fee` enum('on','off') NOT NULL DEFAULT 'off',
  `gift_status` tinyint(1) NOT NULL DEFAULT 1,
  `redeem_status` tinyint(1) NOT NULL DEFAULT 1,
  `slip_status` tinyint(1) NOT NULL DEFAULT 1,
  `promptpay_status` tinyint(1) NOT NULL DEFAULT 1,
  `bg` varchar(50) NOT NULL DEFAULT 'no',
  `main_color` varchar(7) NOT NULL DEFAULT '#ffb300',
  `sec_color` varchar(7) NOT NULL DEFAULT '#ff6d00',
  `contact` varchar(500) NOT NULL DEFAULT '',
  `ann` text DEFAULT NULL,
  `webhook_dc` varchar(500) NOT NULL DEFAULT '',
  `discord_server` varchar(100) NOT NULL DEFAULT '',
  `theme_mode` enum('light','dark') NOT NULL DEFAULT 'light',
  `topup_gift_status` enum('on','off') NOT NULL DEFAULT 'on',
  `topup_redeem_status` enum('on','off') NOT NULL DEFAULT 'on',
  `topup_slip_status` enum('on','off') NOT NULL DEFAULT 'on',
  `topup_promptpay_status` enum('on','off') NOT NULL DEFAULT 'on',
  `contact_facebook` varchar(500) NOT NULL DEFAULT '#',
  `contact_line` varchar(500) NOT NULL DEFAULT '#',
  `contact_discord` varchar(500) NOT NULL DEFAULT '#',
  `contact_messenger` varchar(500) NOT NULL DEFAULT '#',
  `contact_telegram1` varchar(500) NOT NULL DEFAULT '#',
  `contact_telegram2` varchar(500) NOT NULL DEFAULT '#',
  `discord_widget_status` enum('on','off') NOT NULL DEFAULT 'off',
  `how_to_text` text DEFAULT NULL,
  `rules_text` text DEFAULT NULL,
  `announcement_status` enum('on','off') NOT NULL DEFAULT 'on',
  `stats_status` enum('on','off') NOT NULL DEFAULT 'on',
  `discord_topup_notify` enum('on','off') NOT NULL DEFAULT 'on',
  `discord_purchase_notify` enum('on','off') NOT NULL DEFAULT 'on',
  `topup_card_status` enum('on','off') NOT NULL DEFAULT 'on',
  `text_color` varchar(7) NOT NULL DEFAULT '#fff6df',
  `font_family` varchar(40) NOT NULL DEFAULT 'kanit',
  `font_size` int(11) NOT NULL DEFAULT 16,
  `border_color` varchar(7) NOT NULL DEFAULT '#6b2145',
  `bg_color` varchar(7) NOT NULL DEFAULT '#08070a',
  `card_color` varchar(7) NOT NULL DEFAULT '#160d17',
  `button_color` varchar(7) NOT NULL DEFAULT '#ffb300',
  `success_color` varchar(7) NOT NULL DEFAULT '#b8d82e',
  `warning_color` varchar(7) NOT NULL DEFAULT '#ffb300',
  `danger_color` varchar(7) NOT NULL DEFAULT '#ef476f',
  `info_color` varchar(7) NOT NULL DEFAULT '#ff944d',
  `rain_enabled` varchar(3) NOT NULL DEFAULT 'on',
  `rain_density` int(11) NOT NULL DEFAULT 70,
  `glow_enabled` varchar(3) NOT NULL DEFAULT 'on',
  `glow_speed` int(11) NOT NULL DEFAULT 5,
  `rain_white_color` varchar(7) NOT NULL DEFAULT '#ffffff',
  `rain_gray_color` varchar(7) NOT NULL DEFAULT '#aeb2b8',
  `glow_dark_color` varchar(7) NOT NULL DEFAULT '#34363a',
  `glow_light_color` varchar(7) NOT NULL DEFAULT '#ffffff',
  `chat_status` enum('on','off') NOT NULL DEFAULT 'on',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES
(1,'OMG SHOP','assets/omg-logo.png','test','','','','','','0998422059','dark',NULL,'','off',1,1,1,1,'no','#ffb300','#5e5e5e','#','','','','light','on','on','on','on','#','#','#','#','#','#','off','','','on','on','on','on','on','#fff6df','kanit',16,'#6b2145','#08070a','#160d17','#b8d82e','#b8d82e','#ffb300','#ef476f','#ff944d','on',70,'on',5,'#ffffff','#aeb2b8','#34363a','#ffffff','on');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slip_requests`
--

DROP TABLE IF EXISTS `slip_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `slip_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `image_hash` char(64) NOT NULL,
  `image_path` varchar(500) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_note` varchar(500) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_slip_status` (`status`),
  KEY `idx_slip_ref` (`ref`),
  KEY `idx_slip_hash` (`image_hash`),
  KEY `idx_slip_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slip_requests`
--

LOCK TABLES `slip_requests` WRITE;
/*!40000 ALTER TABLE `slip_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `slip_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static`
--

DROP TABLE IF EXISTS `static`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `static` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `m_count` int(10) unsigned NOT NULL DEFAULT 0,
  `c_count` int(10) unsigned NOT NULL DEFAULT 0,
  `s_count` int(10) unsigned NOT NULL DEFAULT 0,
  `sold_count` int(10) unsigned NOT NULL DEFAULT 0,
  `last_change` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static`
--

LOCK TABLES `static` WRITE;
/*!40000 ALTER TABLE `static` DISABLE KEYS */;
INSERT INTO `static` VALUES
(1,0,0,0,0,'2026-10-01 00:05:27');
/*!40000 ALTER TABLE `static` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topup_gift`
--

DROP TABLE IF EXISTS `topup_gift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topup_gift` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `uid` int(10) unsigned DEFAULT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gift_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topup_gift`
--

LOCK TABLES `topup_gift` WRITE;
/*!40000 ALTER TABLE `topup_gift` DISABLE KEYS */;
/*!40000 ALTER TABLE `topup_gift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topup_his`
--

DROP TABLE IF EXISTS `topup_his`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topup_his` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link` varchar(500) NOT NULL DEFAULT '',
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_topup_uid` (`uid`),
  KEY `idx_topup_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topup_his`
--

LOCK TABLES `topup_his` WRITE;
/*!40000 ALTER TABLE `topup_his` DISABLE KEYS */;
/*!40000 ALTER TABLE `topup_his` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `truemoney_card_requests`
--

DROP TABLE IF EXISTS `truemoney_card_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `truemoney_card_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `card_hash` char(64) NOT NULL,
  `card_last4` char(4) NOT NULL,
  `card_encrypted` text NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_note` varchar(500) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_card_status` (`status`),
  KEY `idx_card_hash` (`card_hash`),
  KEY `idx_card_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `truemoney_card_requests`
--

LOCK TABLES `truemoney_card_requests` WRITE;
/*!40000 ALTER TABLE `truemoney_card_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `truemoney_card_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `point` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `rank` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT '0=user, 1=admin',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','$2y$10$VCSIjADNyUyvl4dhuTPtHuRa/J0Gx7AqsX2igXpk4l0a2Om9qfVme','2026-09-30 17:05:27',0.00,0.00,1),
(2,'zombie1150','$2y$10$La/OAALz3OT57MbN4HqjhuMVZeR.jbh9vcF7dNkBgmGbTxZy1E2hq','2026-10-01 01:30:54',0.00,0.00,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'webshop_sale'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-01 20:54:16
