<?php
declare(strict_types=1);

// ใส่ Discord Webhook URL ใหม่ที่สร้างด้วย Regenerate URL
const DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/REPLACE_WITH_NEW_ID/REPLACE_WITH_NEW_TOKEN';

// ค่านี้เป็นคีย์ลับสำหรับเรียก topup_notify.php
const NOTIFY_API_KEY = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET';
