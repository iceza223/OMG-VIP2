<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string
{
    if (empty($_SESSION['download_csrf'])) {
        $_SESSION['download_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['download_csrf'];
}

function is_admin(): bool
{
    return !empty($_SESSION['download_admin']);
}

function redirect_self(): never
{
    header('Location: index.php');
    exit;
}

$message = '';
$error = '';
$isAjaxUpload = (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['upload'])
    && (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest')
);

if (isset($_GET['logout'])) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', (bool)$params['secure'], (bool)$params['httponly']);
    }
    session_destroy();
    redirect_self();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string)($_POST['csrf'] ?? '');
    if (!hash_equals((string)($_SESSION['download_csrf'] ?? ''), $csrf)) {
        $error = 'คำขอไม่ถูกต้อง กรุณาลองใหม่';
    } elseif (isset($_POST['login'])) {
        $attempts = (int)($_SESSION['download_login_attempts'] ?? 0);
        $lastAttempt = (int)($_SESSION['download_last_attempt'] ?? 0);
        if ($attempts >= 5 && time() - $lastAttempt < 60) {
            $error = 'ลองเข้าสู่ระบบบ่อยเกินไป กรุณารอ 1 นาที';
        } else {
            $username = trim((string)($_POST['username'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $_SESSION['download_login_attempts'] = $attempts + 1;
            $_SESSION['download_last_attempt'] = time();
            if (hash_equals(ADMIN_USERNAME, $username) && password_verify($password, ADMIN_PASSWORD_HASH)) {
                session_regenerate_id(true);
                $_SESSION['download_admin'] = true;
                $_SESSION['download_login_attempts'] = 0;
                redirect_self();
            }
            $error = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
        }
    } elseif (isset($_POST['upload']) && is_admin()) {
        $file = $_FILES['download_file'] ?? null;
        $uploadError = is_array($file)
            ? (int)($file['error'] ?? UPLOAD_ERR_NO_FILE)
            : UPLOAD_ERR_NO_FILE;
        if ($uploadError !== UPLOAD_ERR_OK) {
            $error = match ($uploadError) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'ไฟล์ใหญ่เกินขนาดที่เซิร์ฟเวอร์อนุญาต',
                UPLOAD_ERR_PARTIAL => 'อัปโหลดไฟล์ไม่ครบ กรุณาลองใหม่',
                UPLOAD_ERR_NO_FILE => 'กรุณาเลือกไฟล์ที่ต้องการอัปโหลด',
                UPLOAD_ERR_NO_TMP_DIR => 'เซิร์ฟเวอร์ไม่มีโฟลเดอร์ชั่วคราวสำหรับอัปโหลด',
                UPLOAD_ERR_CANT_WRITE => 'เซิร์ฟเวอร์ไม่สามารถเขียนไฟล์ได้',
                default => 'อัปโหลดไม่สำเร็จ กรุณาลองใหม่'
            };
        } elseif ((int)$file['size'] > MAX_FILE_SIZE) {
            $error = 'ไฟล์มีขนาดใหญ่เกิน 500 MB';
        } else {
            $original = basename((string)$file['name']);
            $extension = strtolower((string)pathinfo($original, PATHINFO_EXTENSION));
            if ($original === '' || !in_array($extension, ALLOWED_EXTENSIONS, true)) {
                $error = 'ไม่อนุญาตไฟล์ชนิดนี้';
            } else {
                $safeOriginal = preg_replace('/[^A-Za-z0-9._-]/', '_', $original) ?: 'download.' . $extension;
                $storedName = bin2hex(random_bytes(8)) . '_' . $safeOriginal;
                $destination = DOWNLOAD_DIR . $storedName;
                if (move_uploaded_file((string)$file['tmp_name'], $destination)) {
                    chmod($destination, 0644);
                    $message = 'อัปโหลดไฟล์สำเร็จ';
                } else {
                    $error = 'ไม่สามารถบันทึกไฟล์ได้';
                }
            }
        }
    } elseif (isset($_POST['delete']) && is_admin()) {
        $name = basename((string)($_POST['name'] ?? ''));
        if ($name !== '' && is_file(DOWNLOAD_DIR . $name) && unlink(DOWNLOAD_DIR . $name)) {
            $message = 'ลบไฟล์แล้ว';
        } else {
            $error = 'ไม่พบไฟล์หรือไม่สามารถลบไฟล์ได้';
        }
    }
}

if ($isAjaxUpload) {
    header('Content-Type: application/json; charset=utf-8');
    $ok = $error === '' && $message !== '';
    echo json_encode([
        'ok' => $ok,
        'message' => $ok ? $message : ($error !== '' ? $error : 'อัปโหลดไม่สำเร็จ')
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$files = [];
if (is_admin()) {
    foreach (scandir(DOWNLOAD_DIR) ?: [] as $name) {
        if ($name === '.' || $name === '..' || $name === '.htaccess') {
            continue;
        }
        $path = DOWNLOAD_DIR . $name;
        if (is_file($path)) {
            $files[] = [
                'name' => $name,
                'size' => filesize($path) ?: 0,
                'time' => filemtime($path) ?: 0
            ];
        }
    }
    usort($files, static fn(array $a, array $b): int => $b['time'] <=> $a['time']);
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>OMGVIP Download Manager</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;padding:20px;font-family:Arial,sans-serif;color:#fff;background:radial-gradient(circle at top,#450000,#160000 45%,#050505 85%)}.wrap{width:100%;max-width:850px;margin:auto}.card{padding:22px;margin-bottom:18px;border-radius:18px;background:rgba(15,15,15,.94);border:1px solid rgba(255,50,50,.35);box-shadow:0 0 30px rgba(255,0,0,.12)}h1{margin:0 0 6px;color:#ff4242}h2{margin-top:0}.muted{color:#999}.alert{padding:12px;margin-bottom:15px;border-radius:10px}.ok{background:#07351b;color:#7dffaa}.bad{background:#390000;color:#ff9292}label{display:block;margin:12px 0 6px;color:#bbb}input[type=text],input[type=password],input[type=file]{width:100%;padding:13px;border:1px solid #444;border-radius:9px;background:#090909;color:#fff}button,.button{display:inline-block;border:0;border-radius:9px;padding:12px 16px;color:#fff;font-weight:bold;text-decoration:none;cursor:pointer;background:linear-gradient(90deg,#b00000,#ff3030)}.logout{float:right;background:#333}.file{display:flex;gap:12px;align-items:center;justify-content:space-between;padding:14px 0;border-bottom:1px solid #292929}.file:last-child{border-bottom:0}.name{word-break:break-all}.links{display:flex;gap:7px;flex-wrap:wrap}.copy{background:#194f6d}.del{background:#720d0d}.small{font-size:12px;color:#888}.progress-wrap{margin-top:14px;padding:12px;border-radius:10px;background:#090909;border:1px solid #333}.progress-label{display:flex;justify-content:space-between;gap:10px;margin-bottom:8px;color:#bbb}progress{width:100%;height:13px;accent-color:#ff3030}@media(max-width:600px){.file{display:block}.links{margin-top:10px}.links button{width:100%}.logout{float:none;display:block;margin-top:12px;text-align:center}}
</style>
</head>
<body>
<div class="wrap">
<div class="card">
<h1>OMGVIP Download Manager</h1>
<p class="muted">พื้นที่อัปโหลดไฟล์สำหรับให้ผู้ใช้งานดาวน์โหลด</p>
<?php if (!is_admin()): ?>
    <?php if ($error !== ''): ?><div class="alert bad"><?=h($error)?></div><?php endif; ?>
    <form method="post" autocomplete="off">
        <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
        <label>ชื่อผู้ใช้</label>
        <input type="text" name="username" required autocomplete="username">
        <label>รหัสผ่าน</label>
        <input type="password" name="password" required autocomplete="current-password">
        <button type="submit" name="login" value="1" style="margin-top:16px;width:100%">เข้าสู่ระบบ</button>
    </form>
</div>
<?php else: ?>
    <a class="button logout" href="?logout=1">ออกจากระบบ</a>
    <?php if ($message !== ''): ?><div class="alert ok"><?=h($message)?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="alert bad"><?=h($error)?></div><?php endif; ?>
    <form id="upload-form" method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
        <label>เลือกไฟล์ (สูงสุด 500 MB)</label>
        <input type="file" name="download_file" required>
        <button id="upload-submit" type="submit" name="upload" value="1" style="margin-top:12px">อัปโหลดไฟล์</button>
        <div id="upload-progress" class="progress-wrap" hidden aria-live="polite">
            <div class="progress-label"><span id="upload-status">กำลังเตรียมอัปโหลด...</span><strong id="upload-percent">0%</strong></div>
            <progress id="upload-bar" max="100" value="0">0%</progress>
        </div>
    </form>
</div>
<div class="card">
<h2>ไฟล์ดาวน์โหลด</h2>
<?php if (!$files): ?><p class="muted">ยังไม่มีไฟล์</p><?php else: foreach ($files as $file):
    $url = 'files/' . rawurlencode($file['name']);
?>
<div class="file">
    <div class="name"><strong><?=h($file['name'])?></strong><br><span class="small"><?=number_format($file['size'] / 1024, 1)?> KB</span></div>
    <div class="links">
        <a class="button" href="<?=h($url)?>" target="_blank" rel="noopener">ดาวน์โหลด</a>
        <button class="button copy" type="button" onclick="copyLink(this,'<?=h($url)?>')">คัดลอกลิงก์</button>
        <form method="post" onsubmit="return confirm('ต้องการลบไฟล์นี้หรือไม่?')" style="display:inline">
            <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
            <input type="hidden" name="name" value="<?=h($file['name'])?>">
            <button class="button del" type="submit" name="delete" value="1">ลบ</button>
        </form>
    </div>
</div>
<?php endforeach; endif; ?>
</div>
<?php endif; ?>
</div>
<script>
function copyLink(button,relativeUrl){
 const url=new URL(relativeUrl,window.location.href).href;
 const done=()=>{const old=button.textContent;button.textContent='คัดลอกแล้ว';setTimeout(()=>button.textContent=old,1600)};
 if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(url).then(done).catch(()=>window.prompt('คัดลอกลิงก์นี้:',url));}
 else{const area=document.createElement('textarea');area.value=url;area.style.position='fixed';area.style.opacity='0';document.body.appendChild(area);area.select();try{document.execCommand('copy');done()}catch(e){window.prompt('คัดลอกลิงก์นี้:',url)}area.remove()}
}

const uploadForm=document.getElementById('upload-form');
if(uploadForm){
 uploadForm.addEventListener('submit',function(event){
  event.preventDefault();
  const input=uploadForm.querySelector('input[name="download_file"]');
  if(!input||!input.files.length){return;}
  const progress=document.getElementById('upload-progress');
  const bar=document.getElementById('upload-bar');
  const percent=document.getElementById('upload-percent');
  const status=document.getElementById('upload-status');
  const submit=document.getElementById('upload-submit');
  const xhr=new XMLHttpRequest();
  progress.hidden=false;
  submit.disabled=true;
  status.textContent='กำลังอัปโหลด...';
  xhr.open('POST',uploadForm.action||window.location.href,true);
  xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
  xhr.upload.addEventListener('progress',function(e){
   if(!e.lengthComputable){return;}
   const value=Math.min(100,Math.round((e.loaded/e.total)*100));
   bar.value=value;
   percent.textContent=value+'%';
  });
  xhr.addEventListener('load',function(){
   let response=null;
   try{response=JSON.parse(xhr.responseText);}catch(error){}
   if(xhr.status>=200&&xhr.status<400&&response&&response.ok){
    bar.value=100;
    percent.textContent='100%';
    status.textContent='อัปโหลดเสร็จแล้ว กำลังโหลดรายการไฟล์...';
    status.style.color='#7dffaa';
    window.setTimeout(function(){window.location.reload();},500);
   }else{
    status.textContent=(response&&response.message)||'อัปโหลดไม่สำเร็จ กรุณาลองใหม่';
    status.style.color='#ff9292';
    submit.disabled=false;
   }
  });
  xhr.addEventListener('error',function(){
   status.textContent='การเชื่อมต่อล้มเหลว กรุณาลองใหม่';
   submit.disabled=false;
  });
  const data=new FormData(uploadForm);
  data.append('upload','1');
  xhr.send(data);
 });
}
</script>
</body>
</html>
